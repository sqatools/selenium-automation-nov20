# Mortgage

HOME_PRICE_ID = "chouseprice"
DOWN_PAYMENT_ID = "cdownpayment"
LOAN_TERMS_ID = "cloanterm"
INTEREST_RATE_ID = "cinterestrate"

START_DATE_DROPDOWN_ID = "cstartmonth"
DATE_YEAR_ID = "cstartyear"
PROPERTY_TAX_ID = "cpropertytaxes"
HOME_INSURANCE_ID = "chomeins"
PMI_INSURANCE_ID = "cpmi"
HOA_FREE_ID = "choa"
OTHER_COST_XPATH = "//input[@id='cothercost']"