def test_print():
    a = 10
    b = 20
    assert a + b == 30

def test_divition():
    a = 10
    b = 20
    assert b//a == 2

def test_multiply():
    a = 10
    b = 20
    assert a*b == 300

def test_subs():
    a = 40
    b = 30
    assert a-b == 10


